import { useState } from 'react';
import { LayoutGrid, BarChart3, Trophy, Award, Flame, CheckCircle2 } from 'lucide-react';
import { Header } from '@/components/Header';
import { HabitCard } from '@/components/HabitCard';
import { AddHabitModal } from '@/components/AddHabitModal';
import { BadgesView } from '@/components/BadgesView';
import { LeaderboardView } from '@/components/LeaderboardView';
import { StatsView } from '@/components/StatsView';
import { useHabits } from '@/hooks/useHabits';
import { useTheme } from '@/hooks/useTheme';
import { todayISO, levelTitle } from '@/lib/gamification';

type Tab = 'today' | 'stats' | 'leaderboard' | 'badges';

const TABS: { id: Tab; label: string; icon: typeof LayoutGrid }[] = [
  { id: 'today', label: 'Today', icon: LayoutGrid },
  { id: 'stats', label: 'Stats', icon: BarChart3 },
  { id: 'leaderboard', label: 'Ranks', icon: Trophy },
  { id: 'badges', label: 'Badges', icon: Award },
];

export default function App() {
  const [theme, toggleTheme] = useTheme();
  const { habits, addHabit, deleteHabit, toggleToday, stats } = useHabits();
  const [tab, setTab] = useState<Tab>('today');
  const [modalOpen, setModalOpen] = useState(false);

  const today = todayISO();
  const completedToday = habits.filter((h) => h.completions.includes(today)).length;
  const allDone = habits.length > 0 && completedToday === habits.length;
  const completionPct = habits.length > 0 ? Math.round((completedToday / habits.length) * 100) : 0;

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        stats={stats}
        theme={theme}
        onToggleTheme={toggleTheme}
        onAddHabit={() => setModalOpen(true)}
      />

      <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 py-5 pb-28">
        {tab === 'today' && (
          <div className="space-y-4">
            {/* Hero summary card */}
            <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-brand-500/10 via-rose-500/10 to-amber-500/10 border border-brand-500/20 p-5 animate-slide-up">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-xs text-ink-400 font-medium">
                    {new Date().toLocaleDateString('en', { weekday: 'long', month: 'long', day: 'numeric' })}
                  </p>
                  <h2 className="text-2xl font-bold font-display mt-1">
                    {allDone ? 'All done!' : completionPct === 0 ? "Let's begin" : 'Keep going'}
                  </h2>
                  <p className="text-sm text-ink-500 dark:text-ink-400 mt-0.5">
                    {completedToday} of {habits.length} habits complete today
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <div className="relative h-16 w-16">
                    <svg className="-rotate-90" width="64" height="64">
                      <circle cx="32" cy="32" r="26" fill="none" strokeWidth="6" className="stroke-ink-200 dark:stroke-ink-800" />
                      <circle
                        cx="32" cy="32" r="26" fill="none" strokeWidth="6"
                        stroke="url(#gradHero)"
                        strokeLinecap="round"
                        strokeDasharray={`${(completionPct / 100) * 163.36} 163.36`}
                        style={{ transition: 'stroke-dasharray 0.7s cubic-bezier(0.16,1,0.3,1)' }}
                      />
                      <defs>
                        <linearGradient id="gradHero" x1="0" y1="0" x2="1" y2="1">
                          <stop offset="0%" stopColor="#f97316" />
                          <stop offset="100%" stopColor="#f43f5e" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="absolute inset-0 grid place-items-center">
                      <span className="text-sm font-bold tabular-nums">{completionPct}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick stats row */}
            <div className="grid grid-cols-3 gap-3">
              <QuickStat icon={Flame} label="Current streak" value={`${stats.bestStreak}d`} color="text-orange-500" />
              <QuickStat icon={CheckCircle2} label="Completed today" value={`${completedToday}/${habits.length}`} color="text-emerald-500" />
              <QuickStat icon={Trophy} label="Level" value={`${stats.level}`} color="text-amber-500" />
            </div>

            {allDone && (
              <div className="rounded-2xl bg-gradient-to-r from-emerald-500/15 to-teal-500/15 border border-emerald-500/30 p-4 text-center animate-pop-in">
                <p className="font-bold text-emerald-600 dark:text-emerald-400">All habits complete today!</p>
                <p className="text-xs text-ink-400 mt-0.5">Great work — see you tomorrow. +{habits.length * 10} XP earned today.</p>
              </div>
            )}

            {habits.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-ink-300 dark:border-ink-700 p-10 text-center">
                <p className="text-sm text-ink-400 mb-3">No habits yet. Add your first one to get started.</p>
                <button onClick={() => setModalOpen(true)} className="btn-primary">Add Habit</button>
              </div>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2 stagger">
                {habits.map((h) => (
                  <HabitCard key={h.id} habit={h} onToggle={toggleToday} onDelete={deleteHabit} />
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'stats' && <StatsView habits={habits} stats={stats} />}
        {tab === 'leaderboard' && <LeaderboardView stats={stats} />}
        {tab === 'badges' && <BadgesView stats={stats} />}
      </main>

      {/* Bottom tab bar */}
      <nav className="fixed bottom-0 inset-x-0 z-30 glass">
        <div className="max-w-5xl mx-auto px-2 flex items-center justify-around">
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`relative flex flex-col items-center gap-0.5 py-2.5 px-4 transition-colors ${
                  active ? 'text-brand-500' : 'text-ink-400 hover:text-ink-600 dark:hover:text-ink-200'
                }`}
              >
                <Icon className="h-5 w-5" strokeWidth={active ? 2.5 : 2} />
                <span className="text-[10px] font-semibold">{t.label}</span>
                {active && <span className="absolute top-0 h-0.5 w-8 rounded-full bg-brand-500" />}
              </button>
            );
          })}
        </div>
      </nav>

      <AddHabitModal open={modalOpen} onClose={() => setModalOpen(false)} onAdd={addHabit} />
    </div>
  );
}

function QuickStat({ icon: Icon, label, value, color }: { icon: typeof Flame; label: string; value: string; color: string }) {
  return (
    <div className="card p-3">
      <div className="flex items-center gap-2">
        <Icon className={`h-4 w-4 ${color}`} />
        <span className="text-[11px] text-ink-400 font-medium truncate">{label}</span>
      </div>
      <p className="text-lg font-bold tabular-nums font-display mt-1">{value}</p>
    </div>
  );
}
