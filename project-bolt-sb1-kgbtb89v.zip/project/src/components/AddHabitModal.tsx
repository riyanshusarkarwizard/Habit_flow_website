import { useEffect, useState } from 'react';
import { X, Sparkles } from 'lucide-react';
import { CATEGORY_META, ICON_MAP, type HabitCategory, type HabitIcon } from '@/lib/gamification';

interface AddHabitModalProps {
  open: boolean;
  onClose: () => void;
  onAdd: (name: string, category: HabitCategory, icon: HabitIcon, goalPerWeek: number) => void;
}

const ICON_OPTIONS: HabitIcon[] = ['book', 'dumbbell', 'droplets', 'brain', 'target', 'zap', 'heart', 'coffee', 'moon', 'sun', 'code', 'palette', 'music', 'leaf', 'pencil', 'star', 'sparkles'];
const CATEGORY_OPTIONS = Object.keys(CATEGORY_META) as HabitCategory[];
const GOAL_OPTIONS = [3, 5, 7];

export function AddHabitModal({ open, onClose, onAdd }: AddHabitModalProps) {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<HabitCategory>('mind');
  const [icon, setIcon] = useState<HabitIcon>('book');
  const [goal, setGoal] = useState(7);

  useEffect(() => {
    if (open) {
      setName('');
      setCategory('mind');
      setIcon('book');
      setGoal(7);
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  const submit = () => {
    if (!name.trim()) return;
    onAdd(name, category, icon, goal);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center p-4">
      <div className="absolute inset-0 bg-ink-950/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative w-full max-w-md rounded-3xl glass shadow-2xl p-6 animate-pop-in">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-brand-500 to-rose-500 grid place-items-center">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <h2 className="text-lg font-bold font-display">New Habit</h2>
          </div>
          <button onClick={onClose} aria-label="Close" className="h-8 w-8 grid place-items-center rounded-lg text-ink-400 hover:bg-ink-100 dark:hover:bg-ink-800 transition">
            <X className="h-4 w-4" />
          </button>
        </div>

        <label className="block text-xs font-semibold text-ink-500 mb-1.5">Habit name</label>
        <input
          autoFocus
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && submit()}
          placeholder="e.g. Meditate 10 minutes"
          className="input-field"
        />

        <label className="block text-xs font-semibold text-ink-500 mt-4 mb-1.5">Category</label>
        <div className="grid grid-cols-3 gap-2">
          {CATEGORY_OPTIONS.map((c) => {
            const meta = CATEGORY_META[c];
            return (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={`rounded-xl py-2 text-xs font-semibold border transition active:scale-95 ${
                  category === c
                    ? `${meta.color} border-transparent ring-1 ${meta.ring}`
                    : 'border-ink-200 dark:border-ink-700 text-ink-500 hover:bg-ink-100 dark:hover:bg-ink-800'
                }`}
              >
                {meta.label}
              </button>
            );
          })}
        </div>

        <label className="block text-xs font-semibold text-ink-500 mt-4 mb-1.5">Icon</label>
        <div className="grid grid-cols-9 gap-1.5">
          {ICON_OPTIONS.map((ic) => {
            const Ic = ICON_MAP[ic];
            return (
              <button
                key={ic}
                onClick={() => setIcon(ic)}
                aria-label={ic}
                className={`h-9 w-9 rounded-lg grid place-items-center border-2 transition active:scale-90 ${
                  icon === ic
                    ? 'border-brand-500 bg-brand-500/10 text-brand-500'
                    : 'border-ink-200 dark:border-ink-700 text-ink-500 hover:border-ink-400'
                }`}
              >
                <Ic className="h-4 w-4" />
              </button>
            );
          })}
        </div>

        <label className="block text-xs font-semibold text-ink-500 mt-4 mb-1.5">Weekly goal</label>
        <div className="flex gap-2">
          {GOAL_OPTIONS.map((g) => (
            <button
              key={g}
              onClick={() => setGoal(g)}
              className={`flex-1 rounded-xl py-2 text-xs font-bold border transition active:scale-95 ${
                goal === g
                  ? 'bg-brand-500/10 text-brand-500 border-brand-500'
                  : 'border-ink-200 dark:border-ink-700 text-ink-500 hover:bg-ink-100 dark:hover:bg-ink-800'
              }`}
            >
              {g}×/week
            </button>
          ))}
        </div>

        <button onClick={submit} disabled={!name.trim()} className="btn-primary w-full mt-6 disabled:opacity-40 disabled:cursor-not-allowed">
          Add Habit
        </button>
      </div>
    </div>
  );
}
