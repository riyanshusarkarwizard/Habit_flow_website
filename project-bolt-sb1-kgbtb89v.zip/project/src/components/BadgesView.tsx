import { Award, Lock, Sparkles } from 'lucide-react';
import { BADGES, TIER_META, type GamificationStats } from '@/lib/gamification';

interface BadgesViewProps {
  stats: GamificationStats;
}

export function BadgesView({ stats }: BadgesViewProps) {
  const unlockedIds = new Set(stats.unlockedBadges.map((b) => b.id));
  const unlockedCount = stats.unlockedBadges.length;
  const progressPct = Math.round((unlockedCount / BADGES.length) * 100);

  return (
    <div className="space-y-4">
      {/* Summary header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-amber-500/10 via-orange-500/10 to-rose-500/10 border border-amber-500/20 p-5">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 grid place-items-center shadow-lg shadow-amber-500/30">
            <Award className="h-6 w-6 text-white" />
          </div>
          <div className="flex-1">
            <h2 className="font-bold text-base font-display">Achievements</h2>
            <p className="text-xs text-ink-400">{unlockedCount} of {BADGES.length} unlocked</p>
          </div>
          <div className="text-right">
            <span className="text-2xl font-bold font-display text-gradient">{progressPct}%</span>
          </div>
        </div>
        <div className="h-2 rounded-full bg-ink-200/50 dark:bg-ink-800/50 overflow-hidden mt-3">
          <div className="h-full rounded-full bg-gradient-to-r from-amber-400 to-orange-500 transition-all duration-700" style={{ width: `${progressPct}%` }} />
        </div>
      </div>

      {/* Badge grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 stagger">
        {BADGES.map((badge) => {
          const unlocked = unlockedIds.has(badge.id);
          const Icon = badge.icon;
          const tier = TIER_META[badge.tier];

          return (
            <div
              key={badge.id}
              className={`relative rounded-2xl border p-4 text-center transition-all duration-300 ${
                unlocked
                  ? `${tier.border} bg-gradient-to-br ${tier.color.split(' ')[0] === 'from-amber-300' ? 'from-amber-500/5 to-orange-500/5' : 'from-ink-50 to-ink-100 dark:from-ink-900 dark:to-ink-950'}`
                  : 'border-ink-200 dark:border-ink-800 bg-ink-50 dark:bg-ink-900 opacity-50'
              }`}
            >
              {unlocked && (
                <div className={`mx-auto h-14 w-14 rounded-full bg-gradient-to-br ${tier.color} grid place-items-center mb-2 shadow-lg ${tier.glow} animate-pop-in`}>
                  <Icon className="h-7 w-7 text-white" strokeWidth={2} />
                </div>
              )}
              {!unlocked && (
                <div className="mx-auto h-14 w-14 rounded-full bg-ink-200 dark:bg-ink-800 grid place-items-center mb-2">
                  <Lock className="h-5 w-5 text-ink-400" />
                </div>
              )}
              <p className="text-xs font-bold leading-tight">{badge.label}</p>
              <p className="text-[10px] text-ink-400 mt-0.5 leading-tight">{badge.description}</p>
              {unlocked && (
                <span className="inline-flex items-center gap-0.5 mt-1.5 text-[9px] font-bold uppercase tracking-wide text-amber-500">
                  <Sparkles className="h-2.5 w-2.5" />
                  {tier.label}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
