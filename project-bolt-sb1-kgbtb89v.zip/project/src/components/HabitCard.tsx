import { Check, Flame, Trash2, TrendingUp } from 'lucide-react';
import { CATEGORY_META, ICON_MAP, currentStreak, bestStreakAllTime, todayISO, type Habit } from '@/lib/gamification';

interface HabitCardProps {
  habit: Habit;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

export function HabitCard({ habit, onToggle, onDelete }: HabitCardProps) {
  const Icon = ICON_MAP[habit.icon];
  const cat = CATEGORY_META[habit.category];
  const today = todayISO();
  const done = habit.completions.includes(today);
  const streak = currentStreak(habit.completions);
  const best = bestStreakAllTime(habit.completions);

  const last7 = (() => {
    const days: boolean[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      days.push(habit.completions.includes(`${y}-${m}-${day}`));
    }
    return days;
  })();

  return (
    <div
      className={`group relative rounded-2xl p-4 transition-all duration-300 animate-slide-up ${
        done
          ? 'border border-emerald-500/30 bg-emerald-500/[0.03] dark:bg-emerald-500/[0.04]'
          : 'border border-ink-200 dark:border-ink-800 bg-white dark:bg-ink-900 hover:shadow-lg hover:border-ink-300 dark:hover:border-ink-700'
      }`}
    >
      <div className="flex items-center gap-3">
        <div className={`relative h-12 w-12 rounded-xl grid place-items-center ring-1 ${cat.color} ${cat.ring} shrink-0 transition-transform group-hover:scale-105`}>
          <Icon className="h-5 w-5" strokeWidth={2} />
          {done && (
            <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-emerald-500 grid place-items-center ring-2 ring-white dark:ring-ink-900 animate-pop-in">
              <Check className="h-2.5 w-2.5 text-white" strokeWidth={4} />
            </span>
          )}
        </div>

        <div className="min-w-0 flex-1">
          <h3 className={`font-semibold text-sm leading-tight truncate transition-colors ${done ? 'text-ink-500 dark:text-ink-400' : ''}`}>
            {habit.name}
          </h3>
          <div className="flex items-center gap-2 mt-1">
            <span className={`chip ${cat.color}`}>{cat.label}</span>
            {streak > 0 && (
              <span className="inline-flex items-center gap-0.5 text-[11px] font-bold text-orange-500">
                <Flame className="h-3 w-3" />
                {streak} day{streak > 1 ? 's' : ''}
              </span>
            )}
            {best > 0 && streak !== best && (
              <span className="inline-flex items-center gap-0.5 text-[10px] text-ink-400 font-medium">
                <TrendingUp className="h-2.5 w-2.5" />
                best {best}
              </span>
            )}
          </div>
        </div>

        <button
          onClick={() => onDelete(habit.id)}
          aria-label="Delete habit"
          className="opacity-0 group-hover:opacity-100 h-8 w-8 grid place-items-center rounded-lg text-ink-400 hover:text-rose-500 hover:bg-rose-500/10 transition"
        >
          <Trash2 className="h-4 w-4" />
        </button>

        <button
          onClick={() => onToggle(habit.id)}
          aria-pressed={done}
          aria-label={done ? 'Mark incomplete' : 'Mark complete'}
          className={`relative h-10 w-10 rounded-full grid place-items-center border-2 transition-all duration-300 active:scale-90 ${
            done
              ? 'bg-emerald-500 border-emerald-500 text-white shadow-lg shadow-emerald-500/30 animate-pop-in'
              : 'border-ink-300 dark:border-ink-600 text-transparent hover:border-emerald-500 hover:bg-emerald-500/10'
          }`}
        >
          {done && <span className="absolute inset-0 rounded-full bg-emerald-500 animate-pulse-ring" />}
          <Check className="h-5 w-5 relative z-10" strokeWidth={3} />
        </button>
      </div>

      {/* Mini week strip */}
      <div className="flex items-center gap-1.5 mt-3 pl-[60px]">
        {last7.map((d, i) => (
          <div
            key={i}
            className={`h-1.5 flex-1 rounded-full transition-colors ${
              d ? 'bg-emerald-500' : 'bg-ink-200 dark:bg-ink-800'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
