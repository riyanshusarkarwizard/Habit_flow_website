import { Flame, Moon, Sun, Plus, Sparkles } from 'lucide-react';
import type { GamificationStats } from '@/lib/gamification';
import { levelTitle } from '@/lib/gamification';

interface HeaderProps {
  stats: GamificationStats;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  onAddHabit: () => void;
}

export function Header({ stats, theme, onToggleTheme, onAddHabit }: HeaderProps) {
  const progressPct = Math.min(100, Math.round((stats.pointsInLevel / stats.pointsForNextLevel) * 100));

  return (
    <header className="sticky top-0 z-30 glass transition-colors">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-3 flex items-center gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="relative h-10 w-10 rounded-xl bg-gradient-to-br from-brand-500 to-rose-500 grid place-items-center shadow-lg shadow-brand-500/30 shrink-0">
            <Flame className="h-5 w-5 text-white" strokeWidth={2.5} />
            <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-emerald-400 ring-2 ring-white dark:ring-ink-950" />
          </div>
          <div className="min-w-0">
            <h1 className="text-base font-bold font-display leading-tight tracking-tight">HabitFlow</h1>
            <p className="text-[11px] text-ink-400 leading-tight flex items-center gap-1">
              <Sparkles className="h-2.5 w-2.5" />
              {levelTitle(stats.level)} · Lvl {stats.level}
            </p>
          </div>
        </div>

        <div className="hidden sm:flex flex-1 items-center gap-3 max-w-xs mx-4">
          <div className="flex-1">
            <div className="flex justify-between text-[10px] text-ink-400 mb-1 font-medium">
              <span>{stats.pointsInLevel} XP</span>
              <span>{stats.pointsForNextLevel} XP</span>
            </div>
            <div className="relative h-2.5 rounded-full bg-ink-200 dark:bg-ink-800 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-brand-500 via-rose-500 to-brand-500 bg-[length:200%_100%] animate-shimmer transition-all duration-700 ease-out"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 ml-auto">
          <button onClick={onAddHabit} className="btn-primary">
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">New Habit</span>
          </button>
          <button
            onClick={onToggleTheme}
            aria-label="Toggle theme"
            className="h-9 w-9 grid place-items-center rounded-xl border border-ink-200 dark:border-ink-700 text-ink-600 dark:text-ink-300 hover:bg-ink-100 dark:hover:bg-ink-800 active:scale-95 transition relative overflow-hidden"
          >
            {theme === 'dark' ? <Sun className="h-4 w-4 animate-scale-in" /> : <Moon className="h-4 w-4 animate-scale-in" />}
          </button>
        </div>
      </div>

      <div className="sm:hidden px-4 pb-2.5">
        <div className="flex justify-between text-[10px] text-ink-400 mb-1 font-medium">
          <span>Lvl {stats.level} · {levelTitle(stats.level)}</span>
          <span>{stats.pointsInLevel}/{stats.pointsForNextLevel} XP</span>
        </div>
        <div className="relative h-2.5 rounded-full bg-ink-200 dark:bg-ink-800 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-brand-500 via-rose-500 to-brand-500 bg-[length:200%_100%] animate-shimmer transition-all duration-700 ease-out"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>
    </header>
  );
}
