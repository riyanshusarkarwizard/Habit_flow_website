import { useMemo } from 'react';
import { isoDate, todayISO, last30Days, type Habit } from '@/lib/gamification';

interface HeatmapViewProps {
  habits: Habit[];
}

export function HeatmapView({ habits }: HeatmapViewProps) {
  const days = useMemo(() => {
    return last30Days().map((date) => {
      const count = habits.filter((h) => h.completions.includes(date)).length;
      return { date, count };
    });
  }, [habits]);

  const today = todayISO();

  const intensity = (count: number, max: number) => {
    if (count === 0) return 'bg-ink-200 dark:bg-ink-800';
    const ratio = count / max;
    if (ratio <= 0.25) return 'bg-brand-500/30';
    if (ratio <= 0.5) return 'bg-brand-500/50';
    if (ratio <= 0.75) return 'bg-brand-500/70';
    return 'bg-brand-500';
  };

  const maxCount = Math.max(1, ...days.map((d) => d.count));

  return (
    <div className="card p-4">
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-bold text-sm">30-Day Activity</h2>
        <div className="flex items-center gap-1 text-[10px] text-ink-400">
          <span>Less</span>
          <div className="h-2.5 w-2.5 rounded-sm bg-ink-200 dark:bg-ink-800" />
          <div className="h-2.5 w-2.5 rounded-sm bg-brand-500/30" />
          <div className="h-2.5 w-2.5 rounded-sm bg-brand-500/50" />
          <div className="h-2.5 w-2.5 rounded-sm bg-brand-500/70" />
          <div className="h-2.5 w-2.5 rounded-sm bg-brand-500" />
          <span>More</span>
        </div>
      </div>
      <div className="grid grid-cols-10 sm:grid-cols-15 gap-1.5">
        {days.map((d) => (
          <div
            key={d.date}
            className={`aspect-square rounded-md ${intensity(d.count, maxCount)} ${d.date === today ? 'ring-2 ring-rose-500' : ''} transition-all hover:scale-110 cursor-default`}
            title={`${d.date}: ${d.count} habits`}
          />
        ))}
      </div>
    </div>
  );
}
