import { useMemo } from 'react';
import { Crown, Medal, Flame, TrendingUp } from 'lucide-react';
import { baseLeaderboard, type LeaderboardUser } from '@/lib/sampleData';
import type { GamificationStats } from '@/lib/gamification';

interface LeaderboardViewProps {
  stats: GamificationStats;
}

export function LeaderboardView({ stats }: LeaderboardViewProps) {
  const ranked = useMemo<LeaderboardUser[]>(() => {
    const list = baseLeaderboard.map((u) =>
      u.isYou
        ? { ...u, points: stats.totalPoints, level: stats.level, streak: stats.bestStreak, habitsCount: stats.habitsCount }
        : u,
    );
    return list.sort((a, b) => b.points - a.points);
  }, [stats.totalPoints, stats.level, stats.bestStreak, stats.habitsCount]);

  const yourRank = ranked.findIndex((u) => u.isYou) + 1;
  const podium = ranked.slice(0, 3);
  const rest = ranked.slice(3);

  const podiumHeights = ['h-20', 'h-16', 'h-12'];
  const podiumColors = ['from-amber-400 to-yellow-500', 'from-slate-300 to-slate-400', 'from-orange-400 to-orange-600'];
  const medalColors = ['text-amber-500', 'text-slate-400', 'text-orange-600'];

  return (
    <div className="space-y-4">
      {/* Podium */}
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-4">
          <Crown className="h-5 w-5 text-amber-500" />
          <h2 className="font-bold text-sm">Top 3</h2>
          <span className="ml-auto text-xs font-semibold text-ink-400">You rank #{yourRank}</span>
        </div>

        <div className="flex items-end justify-center gap-2 sm:gap-4">
          {podium.map((user, i) => {
            const sortedIndex = i === 0 ? 1 : i === 1 ? 0 : 2; // visual order: 2nd, 1st, 3rd
            const actualUser = i === 0 ? podium[1] : i === 1 ? podium[0] : podium[2];
            const rank = i === 0 ? 2 : i === 1 ? 1 : 3;
            return (
              <div key={actualUser.id} className="flex flex-col items-center" style={{ animationDelay: `${i * 80}ms` }}>
                <div className={`relative h-14 w-14 rounded-full bg-gradient-to-br ${actualUser.avatarColor} grid place-items-center text-white text-lg font-bold shadow-lg mb-1.5 ${rank === 1 ? 'animate-float' : ''}`}>
                  {actualUser.name[0]}
                  {rank === 1 && <Crown className="absolute -top-3 h-5 w-5 text-amber-500" />}
                </div>
                <p className="text-xs font-bold truncate max-w-[60px]">{actualUser.name.split(' ')[0]}</p>
                <p className="text-[10px] text-ink-400 tabular-nums">{actualUser.points} XP</p>
                <div className={`w-16 sm:w-20 ${podiumHeights[rank - 1]} mt-2 rounded-t-xl bg-gradient-to-b ${podiumColors[rank - 1]} grid place-items-center`}>
                  <span className="text-white font-bold text-lg font-display">{rank}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Rest of leaderboard */}
      <div className="space-y-2 stagger">
        {rest.map((user, i) => {
          const rank = i + 4;
          return (
            <div
              key={user.id}
              className={`flex items-center gap-3 rounded-xl border p-3 transition-all ${
                user.isYou
                  ? 'border-emerald-500/40 bg-emerald-500/5 ring-1 ring-emerald-500/20'
                  : 'border-ink-200 dark:border-ink-800 bg-white dark:bg-ink-900'
              }`}
            >
              <div className="w-6 text-center">
                <span className="text-sm font-bold text-ink-400 tabular-nums">{rank}</span>
              </div>
              <div className={`h-10 w-10 rounded-full bg-gradient-to-br ${user.avatarColor} grid place-items-center text-white text-sm font-bold shadow-md`}>
                {user.name[0]}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">
                  {user.name}
                  {user.isYou && <span className="ml-1.5 text-[10px] text-emerald-500 font-bold">YOU</span>}
                </p>
                <div className="flex items-center gap-3 mt-0.5">
                  <span className="inline-flex items-center gap-0.5 text-[10px] text-ink-400">
                    <Flame className="h-2.5 w-2.5 text-orange-500" />{user.streak}d
                  </span>
                  <span className="inline-flex items-center gap-0.5 text-[10px] text-ink-400">
                    <TrendingUp className="h-2.5 w-2.5" />Lvl {user.level}
                  </span>
                  <span className="text-[10px] text-ink-400">{user.habitsCount} habits</span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold tabular-nums">{user.points}</p>
                <p className="text-[10px] text-ink-400">XP</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
