import { useMemo } from 'react';
import { Flame, Target, Trophy, TrendingUp, Calendar } from 'lucide-react';
import { DonutChart } from '@/components/DonutChart';
import { HeatmapView } from '@/components/HeatmapView';
import { isoDate, todayISO, last7Days, currentStreak, bestStreakAllTime, type Habit, type GamificationStats } from '@/lib/gamification';

interface StatsViewProps {
  habits: Habit[];
  stats: GamificationStats;
}

export function StatsView({ habits, stats }: StatsViewProps) {
  const week = useMemo(() => {
    return last7Days().map((date) => {
      const count = habits.filter((h) => h.completions.includes(date)).length;
      const d = new Date(date);
      return {
        label: d.toLocaleDateString('en', { weekday: 'short' }).slice(0, 1),
        date,
        count,
        total: habits.length,
      };
    });
  }, [habits]);

  const maxCount = Math.max(1, ...week.map((d) => d.count));
  const totalCompletionsThisWeek = week.reduce((s, d) => s + d.count, 0);
  const totalPossible = week.length * habits.length || 1;
  const completionRate = Math.round((totalCompletionsThisWeek / totalPossible) * 100);

  const today = todayISO();
  const completedToday = habits.filter((h) => h.completions.includes(today)).length;

  const donutSegments = [
    { value: completedToday, color: '#10b981' },
    { value: habits.length - completedToday, color: '#e2e8f0' },
  ];

  const perHabitStats = useMemo(() => {
    return habits.map((h) => ({
      habit: h,
      streak: currentStreak(h.completions),
      best: bestStreakAllTime(h.completions),
      weekCount: last7Days().filter((d) => h.completions.includes(d)).length,
    }));
  }, [habits]);

  return (
    <div className="space-y-4">
      {/* Top stat cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 stagger">
        <StatCard icon={Target} label="Today" value={`${completedToday}/${habits.length}`} color="text-emerald-500" bg="bg-emerald-500/10" />
        <StatCard icon={TrendingUp} label="Week Rate" value={`${completionRate}%`} color="text-brand-500" bg="bg-brand-500/10" />
        <StatCard icon={Flame} label="Best Streak" value={`${stats.bestStreak}d`} color="text-orange-500" bg="bg-orange-500/10" />
        <StatCard icon={Trophy} label="Total XP" value={String(stats.totalPoints)} color="text-amber-500" bg="bg-amber-500/10" />
      </div>

      {/* Donut + Bar chart row */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="card p-5 flex flex-col items-center">
          <h2 className="font-bold text-sm mb-4 self-start">Today's Progress</h2>
          <DonutChart
            segments={donutSegments}
            size={140}
            strokeWidth={14}
            centerLabel={`${completionRate}%`}
            centerSub="this week"
          />
          <div className="flex items-center gap-4 mt-4 text-xs">
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />Done</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-ink-200 dark:bg-ink-800" />Remaining</span>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="font-bold text-sm mb-4">Weekly Activity</h2>
          <div className="flex items-end justify-between gap-2 h-40">
            {week.map((d) => {
              const heightPct = (d.count / maxCount) * 100;
              const isToday = d.date === today;
              return (
                <div key={d.date} className="flex-1 flex flex-col items-center gap-2">
                  <span className="text-[10px] font-bold tabular-nums text-ink-500">{d.count > 0 ? d.count : ''}</span>
                  <div className="flex-1 w-full flex items-end">
                    <div
                      className={`w-full rounded-t-lg transition-all duration-700 ease-out ${
                        isToday
                          ? 'bg-gradient-to-t from-brand-500 to-rose-500'
                          : 'bg-ink-300 dark:bg-ink-700'
                      }`}
                      style={{ height: `${Math.max(4, heightPct)}%` }}
                    />
                  </div>
                  <span className={`text-[11px] font-semibold ${isToday ? 'text-brand-500' : 'text-ink-400'}`}>{d.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Heatmap */}
      <HeatmapView habits={habits} />

      {/* Per-habit breakdown */}
      <div className="card p-5">
        <h2 className="font-bold text-sm mb-3 flex items-center gap-1.5">
          <Calendar className="h-4 w-4 text-ink-400" />
          Habit Breakdown
        </h2>
        <div className="space-y-3">
          {perHabitStats.map(({ habit, streak, best, weekCount }) => {
            const goal = habit.goalPerWeek ?? 7;
            const weekPct = Math.min(100, Math.round((weekCount / goal) * 100));
            return (
              <div key={habit.id} className="flex items-center gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-xs font-semibold truncate">{habit.name}</p>
                    <span className="text-[10px] text-ink-400 font-medium ml-2 shrink-0">{weekCount}/{goal} this week</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-ink-200 dark:bg-ink-800 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ${weekPct >= 100 ? 'bg-emerald-500' : 'bg-brand-500'}`}
                      style={{ width: `${weekPct}%` }}
                    />
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="inline-flex items-center gap-0.5 text-[11px] font-bold text-orange-500">
                    <Flame className="h-3 w-3" />{streak}
                  </span>
                  <span className="text-[10px] text-ink-400 font-medium">best {best}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color, bg }: { icon: typeof Flame; label: string; value: string; color: string; bg: string }) {
  return (
    <div className="card p-3.5">
      <div className={`h-8 w-8 rounded-lg ${bg} grid place-items-center mb-2`}>
        <Icon className={`h-4 w-4 ${color}`} />
      </div>
      <p className="text-lg font-bold tabular-nums font-display">{value}</p>
      <p className="text-[11px] text-ink-400 font-medium">{label}</p>
    </div>
  );
}
