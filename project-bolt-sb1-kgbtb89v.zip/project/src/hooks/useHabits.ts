import { useCallback, useMemo } from 'react';
import { useLocalStorage } from './useLocalStorage';
import { computeStats, currentStreak, todayISO, type GamificationStats, type Habit } from '@/lib/gamification';
import { sampleHabits } from '@/lib/sampleData';

export function useHabits() {
  const [habits, setHabits] = useLocalStorage<Habit[]>('habit-habits-v2', sampleHabits);

  const addHabit = useCallback(
    (name: string, category: Habit['category'], icon: Habit['icon'], goalPerWeek: number) => {
      const newHabit: Habit = {
        id: crypto.randomUUID(),
        name: name.trim(),
        category,
        icon,
        createdAt: new Date().toISOString(),
        completions: [],
        goalPerWeek,
      };
      setHabits((prev) => [...prev, newHabit]);
    },
    [setHabits],
  );

  const deleteHabit = useCallback(
    (id: string) => {
      setHabits((prev) => prev.filter((h) => h.id !== id));
    },
    [setHabits],
  );

  const toggleToday = useCallback(
    (id: string) => {
      const today = todayISO();
      setHabits((prev) =>
        prev.map((h) => {
          if (h.id !== id) return h;
          const has = h.completions.includes(today);
          return {
            ...h,
            completions: has ? h.completions.filter((d) => d !== today) : [...h.completions, today],
          };
        }),
      );
    },
    [setHabits],
  );

  const stats: GamificationStats = useMemo(() => computeStats(habits), [habits]);
  const streakById = useMemo(() => {
    const map: Record<string, number> = {};
    for (const h of habits) map[h.id] = currentStreak(h.completions);
    return map;
  }, [habits]);

  return { habits, addHabit, deleteHabit, toggleToday, stats, streakById };
}
