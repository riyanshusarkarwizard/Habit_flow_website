import {
  BookOpen,
  Dumbbell,
  Droplets,
  Flame,
  Trophy,
  Target,
  Zap,
  Star,
  Award,
  Sparkles,
  Brain,
  Heart,
  Coffee,
  Moon,
  Sun,
  Code,
  Palette,
  Music,
  Leaf,
  PencilLine,
  type LucideIcon,
} from 'lucide-react';

export type HabitCategory = 'mind' | 'body' | 'health' | 'productivity' | 'creativity' | 'social';

export interface Habit {
  id: string;
  name: string;
  category: HabitCategory;
  icon: HabitIcon;
  createdAt: string;
  /** ISO date strings (YYYY-MM-DD) that are completed */
  completions: string[];
  /** Optional target frequency per week */
  goalPerWeek?: number;
}

export type HabitIcon =
  | 'book' | 'dumbbell' | 'droplets' | 'target' | 'zap' | 'star' | 'sparkles'
  | 'brain' | 'heart' | 'coffee' | 'moon' | 'sun' | 'code' | 'palette' | 'music' | 'leaf' | 'pencil';

export const ICON_MAP: Record<HabitIcon, LucideIcon> = {
  book: BookOpen,
  dumbbell: Dumbbell,
  droplets: Droplets,
  target: Target,
  zap: Zap,
  star: Star,
  sparkles: Sparkles,
  brain: Brain,
  heart: Heart,
  coffee: Coffee,
  moon: Moon,
  sun: Sun,
  code: Code,
  palette: Palette,
  music: Music,
  leaf: Leaf,
  pencil: PencilLine,
};

export const CATEGORY_META: Record<HabitCategory, { label: string; color: string; ring: string; solid: string; glow: string }> = {
  mind: {
    label: 'Mind',
    color: 'bg-violet-500/10 text-violet-600 dark:text-violet-300',
    ring: 'ring-violet-500/30',
    solid: 'bg-violet-500',
    glow: 'shadow-violet-500/20',
  },
  body: {
    label: 'Body',
    color: 'bg-orange-500/10 text-orange-600 dark:text-orange-300',
    ring: 'ring-orange-500/30',
    solid: 'bg-orange-500',
    glow: 'shadow-orange-500/20',
  },
  health: {
    label: 'Health',
    color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-300',
    ring: 'ring-emerald-500/30',
    solid: 'bg-emerald-500',
    glow: 'shadow-emerald-500/20',
  },
  productivity: {
    label: 'Productivity',
    color: 'bg-blue-500/10 text-blue-600 dark:text-blue-300',
    ring: 'ring-blue-500/30',
    solid: 'bg-blue-500',
    glow: 'shadow-blue-500/20',
  },
  creativity: {
    label: 'Creativity',
    color: 'bg-pink-500/10 text-pink-600 dark:text-pink-300',
    ring: 'ring-pink-500/30',
    solid: 'bg-pink-500',
    glow: 'shadow-pink-500/20',
  },
  social: {
    label: 'Social',
    color: 'bg-amber-500/10 text-amber-600 dark:text-amber-300',
    ring: 'ring-amber-500/30',
    solid: 'bg-amber-500',
    glow: 'shadow-amber-500/20',
  },
};

export interface Badge {
  id: string;
  label: string;
  description: string;
  icon: LucideIcon;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  check: (stats: GamificationStats) => boolean;
}

export interface GamificationStats {
  totalPoints: number;
  level: number;
  pointsInLevel: number;
  pointsForNextLevel: number;
  bestStreak: number;
  habitsCompletedCount: number;
  habitsCount: number;
  unlockedBadges: Badge[];
}

export const XP_PER_COMPLETION = 10;
export const BASE_LEVEL_XP = 100;

export function pointsForLevel(level: number): number {
  return Math.round(BASE_LEVEL_XP * Math.pow(1.4, level - 1));
}

export function levelTitle(level: number): string {
  const titles = [
    'Novice', 'Apprentice', 'Adept', 'Journeyman', 'Expert',
    'Master', 'Grandmaster', 'Legend', 'Mythic', 'Ascendant',
  'Transcendent', 'Eternal',
  ];
  return titles[Math.min(level - 1, titles.length - 1)] ?? 'Eternal';
}

export function computeStats(habits: Habit[]): GamificationStats {
  const totalPoints = habits.reduce((sum, h) => sum + h.completions.length * XP_PER_COMPLETION, 0);
  let level = 1;
  let remaining = totalPoints;
  let needed = pointsForLevel(level);
  while (remaining >= needed) {
    remaining -= needed;
    level += 1;
    needed = pointsForLevel(level);
  }
  const pointsInLevel = remaining;
  const pointsForNextLevel = needed;

  const bestStreak = Math.max(0, ...habits.map((h) => currentStreak(h.completions)));
  const habitsCompletedCount = habits.reduce((sum, h) => sum + h.completions.length, 0);

  const statsBase = {
    totalPoints, level, pointsInLevel, pointsForNextLevel,
    bestStreak, habitsCompletedCount, habitsCount: habits.length,
  };
  const unlockedBadges = BADGES.filter((b) => b.check({ ...statsBase, unlockedBadges: [] }));
  return { ...statsBase, unlockedBadges };
}

export function currentStreak(completions: string[]): number {
  if (completions.length === 0) return 0;
  const set = new Set(completions);
  let streak = 0;
  let cursor = todayISO();
  if (!set.has(cursor)) {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    cursor = isoDate(yesterday);
    if (!set.has(cursor)) return 0;
  }
  while (set.has(cursor)) {
    streak += 1;
    const d = new Date(cursor);
    d.setDate(d.getDate() - 1);
    cursor = isoDate(d);
  }
  return streak;
}

export function bestStreakAllTime(completions: string[]): number {
  if (completions.length === 0) return 0;
  const sorted = [...completions].sort();
  let best = 1;
  let current = 1;
  for (let i = 1; i < sorted.length; i++) {
    const prev = new Date(sorted[i - 1]);
    const curr = new Date(sorted[i]);
    const diff = Math.round((curr.getTime() - prev.getTime()) / 86400000);
    if (diff === 1) {
      current += 1;
      best = Math.max(best, current);
    } else if (diff > 1) {
      current = 1;
    }
  }
  return best;
}

export function todayISO(): string {
  return isoDate(new Date());
}

export function isoDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function last7Days(): string[] {
  const days: string[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(isoDate(d));
  }
  return days;
}

export function last30Days(): string[] {
  const days: string[] = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(isoDate(d));
  }
  return days;
}

export const BADGES: Badge[] = [
  { id: 'first-step', label: 'First Step', description: 'Complete your first habit', icon: Zap, tier: 'bronze', check: (s) => s.habitsCompletedCount >= 1 },
  { id: 'streak-3', label: 'On Fire', description: 'Reach a 3-day streak', icon: Flame, tier: 'bronze', check: (s) => s.bestStreak >= 3 },
  { id: 'streak-7', label: 'Unstoppable', description: 'Reach a 7-day streak', icon: Flame, tier: 'silver', check: (s) => s.bestStreak >= 7 },
  { id: 'points-100', label: 'Centurion', description: 'Earn 100 XP', icon: Star, tier: 'silver', check: (s) => s.totalPoints >= 100 },
  { id: 'points-500', label: 'XP Hunter', description: 'Earn 500 XP', icon: Trophy, tier: 'gold', check: (s) => s.totalPoints >= 500 },
  { id: 'level-5', label: 'Rising Star', description: 'Reach Level 5', icon: Award, tier: 'gold', check: (s) => s.level >= 5 },
  { id: 'habit-master', label: 'Habit Master', description: 'Complete 50 habits', icon: Target, tier: 'platinum', check: (s) => s.habitsCompletedCount >= 50 },
  { id: 'collector', label: 'Collector', description: 'Track 5 habits at once', icon: Sparkles, tier: 'silver', check: (s) => s.habitsCount >= 5 },
];

export const TIER_META: Record<Badge['tier'], { label: string; color: string; border: string; glow: string }> = {
  bronze: { label: 'Bronze', color: 'from-amber-600 to-orange-700', border: 'border-amber-600/30', glow: 'shadow-amber-600/20' },
  silver: { label: 'Silver', color: 'from-slate-300 to-slate-500', border: 'border-slate-400/30', glow: 'shadow-slate-400/20' },
  gold: { label: 'Gold', color: 'from-amber-300 to-yellow-500', border: 'border-amber-400/30', glow: 'shadow-amber-400/20' },
  platinum: { label: 'Platinum', color: 'from-cyan-200 to-violet-400', border: 'border-cyan-300/30', glow: 'shadow-cyan-300/20' },
};
