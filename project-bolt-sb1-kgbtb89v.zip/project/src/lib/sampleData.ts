import type { Habit } from './gamification';
import { isoDate } from './gamification';

function daysAgo(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return isoDate(d);
}

export const sampleHabits: Habit[] = [
  {
    id: 'sample-read',
    name: 'Read 20 pages',
    category: 'mind',
    icon: 'book',
    createdAt: daysAgo(25),
    goalPerWeek: 7,
    completions: [
      daysAgo(25), daysAgo(24), daysAgo(23), daysAgo(22), daysAgo(21),
      daysAgo(18), daysAgo(17), daysAgo(16), daysAgo(15), daysAgo(14),
      daysAgo(11), daysAgo(10), daysAgo(9), daysAgo(8), daysAgo(7),
      daysAgo(6), daysAgo(5), daysAgo(4), daysAgo(3), daysAgo(2), daysAgo(1), daysAgo(0),
    ],
  },
  {
    id: 'sample-workout',
    name: 'Morning workout',
    category: 'body',
    icon: 'dumbbell',
    createdAt: daysAgo(20),
    goalPerWeek: 5,
    completions: [
      daysAgo(20), daysAgo(19), daysAgo(17), daysAgo(16),
      daysAgo(13), daysAgo(12), daysAgo(10), daysAgo(9),
      daysAgo(6), daysAgo(5), daysAgo(4), daysAgo(2), daysAgo(1),
    ],
  },
  {
    id: 'sample-water',
    name: 'Drink 2L water',
    category: 'health',
    icon: 'droplets',
    createdAt: daysAgo(18),
    goalPerWeek: 7,
    completions: [
      daysAgo(18), daysAgo(17), daysAgo(16), daysAgo(15),
      daysAgo(14), daysAgo(13), daysAgo(12), daysAgo(11),
      daysAgo(10), daysAgo(9), daysAgo(8), daysAgo(7),
      daysAgo(6), daysAgo(5), daysAgo(4), daysAgo(3), daysAgo(2), daysAgo(1), daysAgo(0),
    ],
  },
  {
    id: 'sample-meditate',
    name: 'Meditate 10 min',
    category: 'mind',
    icon: 'brain',
    createdAt: daysAgo(12),
    goalPerWeek: 7,
    completions: [
      daysAgo(12), daysAgo(11), daysAgo(10), daysAgo(8),
      daysAgo(6), daysAgo(5), daysAgo(3), daysAgo(2), daysAgo(1), daysAgo(0),
    ],
  },
];

export interface LeaderboardUser {
  id: string;
  name: string;
  points: number;
  level: number;
  streak: number;
  avatarColor: string;
  habitsCount: number;
  isYou?: boolean;
}

export const baseLeaderboard: LeaderboardUser[] = [
  { id: 'u1', name: 'Alex Rivera', points: 2480, level: 8, streak: 21, avatarColor: 'from-rose-500 to-pink-600', habitsCount: 6 },
  { id: 'u2', name: 'Jordan Kim', points: 1960, level: 7, streak: 14, avatarColor: 'from-amber-500 to-orange-600', habitsCount: 5 },
  { id: 'u3', name: 'Sam Chen', points: 1520, level: 6, streak: 9, avatarColor: 'from-teal-500 to-cyan-600', habitsCount: 4 },
  { id: 'u4', name: 'Riley Park', points: 1080, level: 5, streak: 5, avatarColor: 'from-indigo-500 to-violet-600', habitsCount: 4 },
  { id: 'u5', name: 'Casey Brooks', points: 640, level: 3, streak: 3, avatarColor: 'from-fuchsia-500 to-purple-600', habitsCount: 3 },
  { id: 'u6', name: 'Morgan Lee', points: 420, level: 2, streak: 1, avatarColor: 'from-cyan-500 to-blue-600', habitsCount: 2 },
  { id: 'u7', name: 'You', points: 0, level: 1, streak: 0, avatarColor: 'from-emerald-500 to-teal-600', habitsCount: 0, isYou: true },
];
